"use strict";
class Md_Item {
    constructor(icon,title,click) {
       this.icon=icon
        this.title=title
        this.click=click
    }
}